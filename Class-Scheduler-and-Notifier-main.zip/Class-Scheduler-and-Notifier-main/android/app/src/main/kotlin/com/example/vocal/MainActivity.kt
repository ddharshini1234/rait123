package com.example.vocal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
