class ClassSchedule {
  String? name;
  String? start;
  String? end;
  DateTime? date;
  String? phone;
  String? token;
  Map<String, dynamic>? entry;

  ClassSchedule(
      {this.name, this.start, this.end, this.date, this.phone, this.token, this.entry});
}
