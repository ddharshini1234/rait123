# Vocal

An App for Teachers and Students to manage class schedules.

## App is under development.

## Current app screenshots

| Login Screen | OTP Screen |
| --- | --- |
| ![login_screen](images/1.jpg) | ![login_screen](images/2.jpg) |

| Home Screen | Menu Screen |
| --- | --- |
| ![login_screen](images/3.jpg) | ![login_screen](images/4.jpg) |

| Add Students | Create Schedule |
| --- | --- |
| ![login_screen](images/5.jpg) | ![login_screen](images/6.jpg) |

| Add Classes | Save Schedule |
| --- | --- |
| ![login_screen](images/7.jpg) | ![login_screen](images/9.jpg) |

| Updated Home Screen | Edit Class |
| --- | --- |
| ![login_screen](images/10.jpg) | ![login_screen](images/11.jpg) |

| Delete Class | Confirm Delete |
| --- | --- |
| ![login_screen](images/12.jpg) | ![login_screen](images/13.jpg) |


